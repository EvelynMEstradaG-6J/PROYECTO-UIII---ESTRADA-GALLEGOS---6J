// Export pages
export 'iniciar_sesion/iniciar_sesion_widget.dart' show IniciarSesionWidget;
export 'inicio/inicio_widget.dart' show InicioWidget;
export 'articulos/articulos_widget.dart' show ArticulosWidget;
export 'empleado2/empleado2_widget.dart' show Empleado2Widget;
export 'clientes/clientes_widget.dart' show ClientesWidget;
export 'consumo/consumo_widget.dart' show ConsumoWidget;
export 'empleado1/empleado1_widget.dart' show Empleado1Widget;
export 'contratar/contratar_widget.dart' show ContratarWidget;
export 'atencion_cliente/atencion_cliente_widget.dart'
    show AtencionClienteWidget;
export 'pagos/pagos_widget.dart' show PagosWidget;
export 'cancelar_telmex/cancelar_telmex_widget.dart' show CancelarTelmexWidget;
